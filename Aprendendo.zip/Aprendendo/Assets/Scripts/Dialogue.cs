﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dialogue : MonoBehaviour
{
    public Enemy enemy;
    public Text txt;
    public float cooldown;

    private Animator anim;
    private int selected;
    private string str;
    public bool showed;

    private void Start()
    {
        anim = GetComponent<Animator>();
    }

    public void showDialog()
    {
        StopAllCoroutines();
        showed = true;
        anim.SetTrigger("open");
        selected = 0;
        str = enemy.falas[selected];
        loadLetters();
    }

    public void loadLetters()
    {
        txt.text = "";
        char[] chars = str.ToCharArray();
        for (int i = 0; i < chars.Length; i++)
            StartCoroutine(getLetter(chars[i], i));
    }

    public void nextDialog()
    {
        if (enemy.falas.Count == selected + 1)
        {
            endDialog();
        }
        else
        {
            selected++;
            str = enemy.falas[selected];
            loadLetters();
        }
    }

    public void endDialog()
    {
        showed = false;
        anim.SetTrigger("close");
        str = "";
        txt.text = "";
    }

    IEnumerator getLetter(char c, int i)
    {
        yield return new WaitForSeconds(cooldown * i);
        txt.text += c.ToString();
    }
}