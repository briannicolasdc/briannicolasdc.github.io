﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Bt_Start()
    {
        Debug.Log("Mudou de scena");
        //Application.LoadLevel("");
    }

    public void Bt_Options()
    {
        Debug.Log("Opções ativadas");
        //Application.LoadLevel("");
    }

    public void Bt_Exit()
    {
        Debug.Log("Voce saiu do jogo");
        Application.Quit();
    }

}
