﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("EnemyConfig")]
    public string name;
    public int damage;
    public int speed;
    public int life;
    [Header("Imports")]
    public Dialogue dialogue;
    public List<string> falas = new List<string>();

    private void Update()
    {
        if (Vector3.Distance(FindObjectOfType<Char>().transform.position, transform.position) < 1)
        {
            if (Input.GetKeyUp(KeyCode.X) && dialogue.showed == false)
            {
                dialogue.enemy = this;
                dialogue.showDialog();
            }
        }

    }
}
