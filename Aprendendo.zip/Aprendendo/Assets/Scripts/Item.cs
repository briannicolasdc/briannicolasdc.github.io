﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{

    public int id;
    public int count;

    private Char Char;
    private Inventory inv;

    private void Start()
    {
        Char = FindObjectOfType<Char>();
        inv = FindObjectOfType<Inventory>();
    }

    // Update is called once per frame
    private void Update()
    {
        if(Vector2.Distance(Char.transform.position,transform.position) < 1)
        {
            if(Input.GetKeyDown(KeyCode.E))
            {
                inv.addItem(id, count);
                Destroy(gameObject);
            }
        }
    }
}
